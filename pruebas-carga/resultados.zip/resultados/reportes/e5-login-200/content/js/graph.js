/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
$(document).ready(function() {

    $(".click-title").mouseenter( function(    e){
        e.preventDefault();
        this.style.cursor="pointer";
    });
    $(".click-title").mousedown( function(event){
        event.preventDefault();
    });

    // Ugly code while this script is shared among several pages
    try{
        refreshHitsPerSecond(true);
    } catch(e){}
    try{
        refreshResponseTimeOverTime(true);
    } catch(e){}
    try{
        refreshResponseTimePercentiles();
    } catch(e){}
});


var responseTimePercentilesInfos = {
        data: {"result": {"minY": 132.0, "minX": 0.0, "maxY": 4198.0, "series": [{"data": [[0.0, 132.0], [0.1, 135.0], [0.2, 164.0], [0.3, 164.0], [0.4, 173.0], [0.5, 181.0], [0.6, 184.0], [0.7, 186.0], [0.8, 195.0], [0.9, 198.0], [1.0, 198.0], [1.1, 199.0], [1.2, 202.0], [1.3, 202.0], [1.4, 209.0], [1.5, 211.0], [1.6, 214.0], [1.7, 214.0], [1.8, 219.0], [1.9, 219.0], [2.0, 222.0], [2.1, 227.0], [2.2, 238.0], [2.3, 238.0], [2.4, 257.0], [2.5, 262.0], [2.6, 267.0], [2.7, 269.0], [2.8, 273.0], [2.9, 277.0], [3.0, 280.0], [3.1, 280.0], [3.2, 281.0], [3.3, 281.0], [3.4, 283.0], [3.5, 288.0], [3.6, 292.0], [3.7, 292.0], [3.8, 301.0], [3.9, 302.0], [4.0, 303.0], [4.1, 303.0], [4.2, 309.0], [4.3, 310.0], [4.4, 319.0], [4.5, 330.0], [4.6, 334.0], [4.7, 334.0], [4.8, 338.0], [4.9, 344.0], [5.0, 346.0], [5.1, 349.0], [5.2, 350.0], [5.3, 358.0], [5.4, 359.0], [5.5, 360.0], [5.6, 361.0], [5.7, 366.0], [5.8, 378.0], [5.9, 382.0], [6.0, 382.0], [6.1, 384.0], [6.2, 387.0], [6.3, 390.0], [6.4, 391.0], [6.5, 397.0], [6.6, 398.0], [6.7, 406.0], [6.8, 409.0], [6.9, 409.0], [7.0, 410.0], [7.1, 410.0], [7.2, 412.0], [7.3, 413.0], [7.4, 413.0], [7.5, 416.0], [7.6, 424.0], [7.7, 425.0], [7.8, 426.0], [7.9, 430.0], [8.0, 433.0], [8.1, 437.0], [8.2, 437.0], [8.3, 438.0], [8.4, 441.0], [8.5, 443.0], [8.6, 445.0], [8.7, 446.0], [8.8, 451.0], [8.9, 451.0], [9.0, 453.0], [9.1, 453.0], [9.2, 455.0], [9.3, 458.0], [9.4, 459.0], [9.5, 460.0], [9.6, 461.0], [9.7, 462.0], [9.8, 467.0], [9.9, 472.0], [10.0, 474.0], [10.1, 476.0], [10.2, 481.0], [10.3, 482.0], [10.4, 482.0], [10.5, 483.0], [10.6, 487.0], [10.7, 487.0], [10.8, 488.0], [10.9, 488.0], [11.0, 488.0], [11.1, 496.0], [11.2, 496.0], [11.3, 498.0], [11.4, 499.0], [11.5, 499.0], [11.6, 499.0], [11.7, 500.0], [11.8, 501.0], [11.9, 508.0], [12.0, 508.0], [12.1, 510.0], [12.2, 511.0], [12.3, 512.0], [12.4, 514.0], [12.5, 514.0], [12.6, 516.0], [12.7, 522.0], [12.8, 530.0], [12.9, 530.0], [13.0, 531.0], [13.1, 531.0], [13.2, 532.0], [13.3, 533.0], [13.4, 534.0], [13.5, 536.0], [13.6, 537.0], [13.7, 537.0], [13.8, 538.0], [13.9, 540.0], [14.0, 544.0], [14.1, 545.0], [14.2, 546.0], [14.3, 547.0], [14.4, 550.0], [14.5, 550.0], [14.6, 551.0], [14.7, 551.0], [14.8, 555.0], [14.9, 558.0], [15.0, 559.0], [15.1, 560.0], [15.2, 561.0], [15.3, 562.0], [15.4, 564.0], [15.5, 568.0], [15.6, 571.0], [15.7, 571.0], [15.8, 576.0], [15.9, 578.0], [16.0, 579.0], [16.1, 580.0], [16.2, 583.0], [16.3, 584.0], [16.4, 590.0], [16.5, 590.0], [16.6, 590.0], [16.7, 596.0], [16.8, 598.0], [16.9, 604.0], [17.0, 607.0], [17.1, 609.0], [17.2, 612.0], [17.3, 613.0], [17.4, 615.0], [17.5, 616.0], [17.6, 616.0], [17.7, 618.0], [17.8, 619.0], [17.9, 620.0], [18.0, 623.0], [18.1, 623.0], [18.2, 623.0], [18.3, 624.0], [18.4, 626.0], [18.5, 627.0], [18.6, 627.0], [18.7, 632.0], [18.8, 633.0], [18.9, 634.0], [19.0, 635.0], [19.1, 637.0], [19.2, 639.0], [19.3, 643.0], [19.4, 643.0], [19.5, 645.0], [19.6, 647.0], [19.7, 650.0], [19.8, 653.0], [19.9, 656.0], [20.0, 657.0], [20.1, 659.0], [20.2, 662.0], [20.3, 663.0], [20.4, 664.0], [20.5, 664.0], [20.6, 675.0], [20.7, 676.0], [20.8, 683.0], [20.9, 687.0], [21.0, 694.0], [21.1, 695.0], [21.2, 698.0], [21.3, 701.0], [21.4, 705.0], [21.5, 707.0], [21.6, 708.0], [21.7, 711.0], [21.8, 715.0], [21.9, 716.0], [22.0, 716.0], [22.1, 718.0], [22.2, 721.0], [22.3, 722.0], [22.4, 722.0], [22.5, 722.0], [22.6, 723.0], [22.7, 723.0], [22.8, 728.0], [22.9, 730.0], [23.0, 734.0], [23.1, 734.0], [23.2, 742.0], [23.3, 743.0], [23.4, 746.0], [23.5, 749.0], [23.6, 751.0], [23.7, 755.0], [23.8, 755.0], [23.9, 756.0], [24.0, 756.0], [24.1, 756.0], [24.2, 756.0], [24.3, 761.0], [24.4, 763.0], [24.5, 764.0], [24.6, 766.0], [24.7, 768.0], [24.8, 768.0], [24.9, 769.0], [25.0, 773.0], [25.1, 773.0], [25.2, 775.0], [25.3, 776.0], [25.4, 776.0], [25.5, 780.0], [25.6, 781.0], [25.7, 787.0], [25.8, 787.0], [25.9, 793.0], [26.0, 794.0], [26.1, 794.0], [26.2, 796.0], [26.3, 799.0], [26.4, 806.0], [26.5, 807.0], [26.6, 807.0], [26.7, 813.0], [26.8, 813.0], [26.9, 814.0], [27.0, 819.0], [27.1, 825.0], [27.2, 825.0], [27.3, 827.0], [27.4, 827.0], [27.5, 827.0], [27.6, 832.0], [27.7, 844.0], [27.8, 848.0], [27.9, 848.0], [28.0, 849.0], [28.1, 851.0], [28.2, 852.0], [28.3, 853.0], [28.4, 854.0], [28.5, 855.0], [28.6, 855.0], [28.7, 857.0], [28.8, 862.0], [28.9, 862.0], [29.0, 866.0], [29.1, 867.0], [29.2, 871.0], [29.3, 872.0], [29.4, 876.0], [29.5, 876.0], [29.6, 881.0], [29.7, 886.0], [29.8, 890.0], [29.9, 890.0], [30.0, 894.0], [30.1, 896.0], [30.2, 896.0], [30.3, 897.0], [30.4, 899.0], [30.5, 902.0], [30.6, 903.0], [30.7, 903.0], [30.8, 906.0], [30.9, 911.0], [31.0, 916.0], [31.1, 919.0], [31.2, 919.0], [31.3, 919.0], [31.4, 921.0], [31.5, 922.0], [31.6, 926.0], [31.7, 926.0], [31.8, 927.0], [31.9, 928.0], [32.0, 928.0], [32.1, 933.0], [32.2, 935.0], [32.3, 936.0], [32.4, 937.0], [32.5, 937.0], [32.6, 938.0], [32.7, 940.0], [32.8, 943.0], [32.9, 947.0], [33.0, 947.0], [33.1, 949.0], [33.2, 952.0], [33.3, 955.0], [33.4, 958.0], [33.5, 958.0], [33.6, 959.0], [33.7, 963.0], [33.8, 965.0], [33.9, 965.0], [34.0, 966.0], [34.1, 966.0], [34.2, 980.0], [34.3, 984.0], [34.4, 985.0], [34.5, 985.0], [34.6, 987.0], [34.7, 988.0], [34.8, 991.0], [34.9, 991.0], [35.0, 995.0], [35.1, 998.0], [35.2, 999.0], [35.3, 1000.0], [35.4, 1001.0], [35.5, 1003.0], [35.6, 1003.0], [35.7, 1003.0], [35.8, 1010.0], [35.9, 1011.0], [36.0, 1011.0], [36.1, 1011.0], [36.2, 1012.0], [36.3, 1017.0], [36.4, 1018.0], [36.5, 1024.0], [36.6, 1025.0], [36.7, 1026.0], [36.8, 1033.0], [36.9, 1034.0], [37.0, 1038.0], [37.1, 1039.0], [37.2, 1041.0], [37.3, 1049.0], [37.4, 1053.0], [37.5, 1054.0], [37.6, 1054.0], [37.7, 1060.0], [37.8, 1063.0], [37.9, 1069.0], [38.0, 1069.0], [38.1, 1071.0], [38.2, 1071.0], [38.3, 1075.0], [38.4, 1076.0], [38.5, 1077.0], [38.6, 1077.0], [38.7, 1077.0], [38.8, 1077.0], [38.9, 1080.0], [39.0, 1081.0], [39.1, 1081.0], [39.2, 1084.0], [39.3, 1089.0], [39.4, 1091.0], [39.5, 1093.0], [39.6, 1096.0], [39.7, 1098.0], [39.8, 1103.0], [39.9, 1104.0], [40.0, 1105.0], [40.1, 1107.0], [40.2, 1109.0], [40.3, 1114.0], [40.4, 1115.0], [40.5, 1119.0], [40.6, 1120.0], [40.7, 1120.0], [40.8, 1121.0], [40.9, 1122.0], [41.0, 1123.0], [41.1, 1130.0], [41.2, 1135.0], [41.3, 1137.0], [41.4, 1138.0], [41.5, 1140.0], [41.6, 1140.0], [41.7, 1143.0], [41.8, 1146.0], [41.9, 1147.0], [42.0, 1149.0], [42.1, 1152.0], [42.2, 1155.0], [42.3, 1160.0], [42.4, 1160.0], [42.5, 1160.0], [42.6, 1162.0], [42.7, 1162.0], [42.8, 1164.0], [42.9, 1165.0], [43.0, 1166.0], [43.1, 1166.0], [43.2, 1168.0], [43.3, 1168.0], [43.4, 1170.0], [43.5, 1176.0], [43.6, 1179.0], [43.7, 1182.0], [43.8, 1192.0], [43.9, 1193.0], [44.0, 1193.0], [44.1, 1195.0], [44.2, 1202.0], [44.3, 1203.0], [44.4, 1203.0], [44.5, 1204.0], [44.6, 1204.0], [44.7, 1210.0], [44.8, 1211.0], [44.9, 1211.0], [45.0, 1212.0], [45.1, 1213.0], [45.2, 1213.0], [45.3, 1215.0], [45.4, 1228.0], [45.5, 1229.0], [45.6, 1229.0], [45.7, 1230.0], [45.8, 1231.0], [45.9, 1241.0], [46.0, 1244.0], [46.1, 1246.0], [46.2, 1248.0], [46.3, 1250.0], [46.4, 1253.0], [46.5, 1255.0], [46.6, 1256.0], [46.7, 1256.0], [46.8, 1261.0], [46.9, 1262.0], [47.0, 1267.0], [47.1, 1267.0], [47.2, 1272.0], [47.3, 1272.0], [47.4, 1273.0], [47.5, 1275.0], [47.6, 1277.0], [47.7, 1281.0], [47.8, 1285.0], [47.9, 1287.0], [48.0, 1291.0], [48.1, 1293.0], [48.2, 1297.0], [48.3, 1299.0], [48.4, 1304.0], [48.5, 1309.0], [48.6, 1310.0], [48.7, 1310.0], [48.8, 1311.0], [48.9, 1311.0], [49.0, 1317.0], [49.1, 1318.0], [49.2, 1321.0], [49.3, 1321.0], [49.4, 1323.0], [49.5, 1323.0], [49.6, 1323.0], [49.7, 1327.0], [49.8, 1329.0], [49.9, 1333.0], [50.0, 1335.0], [50.1, 1338.0], [50.2, 1338.0], [50.3, 1343.0], [50.4, 1344.0], [50.5, 1344.0], [50.6, 1346.0], [50.7, 1346.0], [50.8, 1355.0], [50.9, 1357.0], [51.0, 1358.0], [51.1, 1360.0], [51.2, 1360.0], [51.3, 1363.0], [51.4, 1364.0], [51.5, 1365.0], [51.6, 1369.0], [51.7, 1371.0], [51.8, 1377.0], [51.9, 1384.0], [52.0, 1386.0], [52.1, 1388.0], [52.2, 1397.0], [52.3, 1398.0], [52.4, 1400.0], [52.5, 1401.0], [52.6, 1403.0], [52.7, 1403.0], [52.8, 1405.0], [52.9, 1407.0], [53.0, 1410.0], [53.1, 1412.0], [53.2, 1412.0], [53.3, 1419.0], [53.4, 1423.0], [53.5, 1425.0], [53.6, 1433.0], [53.7, 1436.0], [53.8, 1438.0], [53.9, 1439.0], [54.0, 1445.0], [54.1, 1446.0], [54.2, 1447.0], [54.3, 1448.0], [54.4, 1450.0], [54.5, 1457.0], [54.6, 1464.0], [54.7, 1472.0], [54.8, 1477.0], [54.9, 1477.0], [55.0, 1477.0], [55.1, 1479.0], [55.2, 1481.0], [55.3, 1485.0], [55.4, 1486.0], [55.5, 1487.0], [55.6, 1490.0], [55.7, 1491.0], [55.8, 1493.0], [55.9, 1496.0], [56.0, 1502.0], [56.1, 1514.0], [56.2, 1514.0], [56.3, 1514.0], [56.4, 1524.0], [56.5, 1527.0], [56.6, 1528.0], [56.7, 1529.0], [56.8, 1532.0], [56.9, 1537.0], [57.0, 1540.0], [57.1, 1540.0], [57.2, 1542.0], [57.3, 1546.0], [57.4, 1546.0], [57.5, 1549.0], [57.6, 1551.0], [57.7, 1553.0], [57.8, 1554.0], [57.9, 1554.0], [58.0, 1556.0], [58.1, 1558.0], [58.2, 1559.0], [58.3, 1561.0], [58.4, 1563.0], [58.5, 1568.0], [58.6, 1570.0], [58.7, 1575.0], [58.8, 1584.0], [58.9, 1585.0], [59.0, 1595.0], [59.1, 1596.0], [59.2, 1600.0], [59.3, 1603.0], [59.4, 1604.0], [59.5, 1611.0], [59.6, 1611.0], [59.7, 1612.0], [59.8, 1617.0], [59.9, 1620.0], [60.0, 1631.0], [60.1, 1636.0], [60.2, 1638.0], [60.3, 1638.0], [60.4, 1645.0], [60.5, 1647.0], [60.6, 1650.0], [60.7, 1651.0], [60.8, 1658.0], [60.9, 1666.0], [61.0, 1666.0], [61.1, 1668.0], [61.2, 1669.0], [61.3, 1680.0], [61.4, 1681.0], [61.5, 1690.0], [61.6, 1690.0], [61.7, 1693.0], [61.8, 1694.0], [61.9, 1695.0], [62.0, 1696.0], [62.1, 1701.0], [62.2, 1702.0], [62.3, 1703.0], [62.4, 1706.0], [62.5, 1711.0], [62.6, 1719.0], [62.7, 1719.0], [62.8, 1719.0], [62.9, 1720.0], [63.0, 1725.0], [63.1, 1729.0], [63.2, 1734.0], [63.3, 1735.0], [63.4, 1741.0], [63.5, 1746.0], [63.6, 1746.0], [63.7, 1761.0], [63.8, 1761.0], [63.9, 1763.0], [64.0, 1765.0], [64.1, 1768.0], [64.2, 1769.0], [64.3, 1771.0], [64.4, 1789.0], [64.5, 1789.0], [64.6, 1797.0], [64.7, 1798.0], [64.8, 1799.0], [64.9, 1802.0], [65.0, 1806.0], [65.1, 1808.0], [65.2, 1809.0], [65.3, 1809.0], [65.4, 1813.0], [65.5, 1820.0], [65.6, 1820.0], [65.7, 1823.0], [65.8, 1829.0], [65.9, 1836.0], [66.0, 1839.0], [66.1, 1844.0], [66.2, 1856.0], [66.3, 1856.0], [66.4, 1858.0], [66.5, 1862.0], [66.6, 1870.0], [66.7, 1872.0], [66.8, 1874.0], [66.9, 1876.0], [67.0, 1881.0], [67.1, 1886.0], [67.2, 1890.0], [67.3, 1893.0], [67.4, 1895.0], [67.5, 1896.0], [67.6, 1896.0], [67.7, 1902.0], [67.8, 1904.0], [67.9, 1904.0], [68.0, 1904.0], [68.1, 1907.0], [68.2, 1919.0], [68.3, 1920.0], [68.4, 1921.0], [68.5, 1925.0], [68.6, 1926.0], [68.7, 1928.0], [68.8, 1931.0], [68.9, 1932.0], [69.0, 1946.0], [69.1, 1951.0], [69.2, 1953.0], [69.3, 1955.0], [69.4, 1956.0], [69.5, 1964.0], [69.6, 1964.0], [69.7, 1968.0], [69.8, 1976.0], [69.9, 1989.0], [70.0, 1994.0], [70.1, 1995.0], [70.2, 1998.0], [70.3, 2003.0], [70.4, 2008.0], [70.5, 2013.0], [70.6, 2014.0], [70.7, 2014.0], [70.8, 2015.0], [70.9, 2019.0], [71.0, 2023.0], [71.1, 2024.0], [71.2, 2027.0], [71.3, 2034.0], [71.4, 2035.0], [71.5, 2038.0], [71.6, 2044.0], [71.7, 2046.0], [71.8, 2049.0], [71.9, 2050.0], [72.0, 2053.0], [72.1, 2056.0], [72.2, 2057.0], [72.3, 2058.0], [72.4, 2058.0], [72.5, 2059.0], [72.6, 2063.0], [72.7, 2066.0], [72.8, 2069.0], [72.9, 2070.0], [73.0, 2071.0], [73.1, 2076.0], [73.2, 2080.0], [73.3, 2086.0], [73.4, 2088.0], [73.5, 2095.0], [73.6, 2099.0], [73.7, 2099.0], [73.8, 2101.0], [73.9, 2107.0], [74.0, 2111.0], [74.1, 2112.0], [74.2, 2113.0], [74.3, 2115.0], [74.4, 2116.0], [74.5, 2117.0], [74.6, 2127.0], [74.7, 2128.0], [74.8, 2129.0], [74.9, 2129.0], [75.0, 2133.0], [75.1, 2134.0], [75.2, 2135.0], [75.3, 2135.0], [75.4, 2138.0], [75.5, 2139.0], [75.6, 2140.0], [75.7, 2145.0], [75.8, 2147.0], [75.9, 2150.0], [76.0, 2156.0], [76.1, 2168.0], [76.2, 2174.0], [76.3, 2175.0], [76.4, 2177.0], [76.5, 2177.0], [76.6, 2179.0], [76.7, 2184.0], [76.8, 2188.0], [76.9, 2191.0], [77.0, 2200.0], [77.1, 2202.0], [77.2, 2204.0], [77.3, 2205.0], [77.4, 2218.0], [77.5, 2228.0], [77.6, 2232.0], [77.7, 2233.0], [77.8, 2233.0], [77.9, 2243.0], [78.0, 2259.0], [78.1, 2265.0], [78.2, 2269.0], [78.3, 2277.0], [78.4, 2292.0], [78.5, 2295.0], [78.6, 2296.0], [78.7, 2297.0], [78.8, 2297.0], [78.9, 2303.0], [79.0, 2306.0], [79.1, 2319.0], [79.2, 2323.0], [79.3, 2325.0], [79.4, 2327.0], [79.5, 2328.0], [79.6, 2338.0], [79.7, 2340.0], [79.8, 2350.0], [79.9, 2365.0], [80.0, 2366.0], [80.1, 2373.0], [80.2, 2379.0], [80.3, 2381.0], [80.4, 2388.0], [80.5, 2388.0], [80.6, 2390.0], [80.7, 2398.0], [80.8, 2404.0], [80.9, 2404.0], [81.0, 2404.0], [81.1, 2406.0], [81.2, 2406.0], [81.3, 2413.0], [81.4, 2413.0], [81.5, 2417.0], [81.6, 2421.0], [81.7, 2422.0], [81.8, 2428.0], [81.9, 2430.0], [82.0, 2430.0], [82.1, 2440.0], [82.2, 2451.0], [82.3, 2453.0], [82.4, 2455.0], [82.5, 2455.0], [82.6, 2463.0], [82.7, 2464.0], [82.8, 2464.0], [82.9, 2469.0], [83.0, 2489.0], [83.1, 2492.0], [83.2, 2501.0], [83.3, 2501.0], [83.4, 2504.0], [83.5, 2505.0], [83.6, 2510.0], [83.7, 2520.0], [83.8, 2523.0], [83.9, 2526.0], [84.0, 2532.0], [84.1, 2537.0], [84.2, 2538.0], [84.3, 2542.0], [84.4, 2546.0], [84.5, 2546.0], [84.6, 2549.0], [84.7, 2552.0], [84.8, 2557.0], [84.9, 2557.0], [85.0, 2559.0], [85.1, 2560.0], [85.2, 2562.0], [85.3, 2562.0], [85.4, 2575.0], [85.5, 2578.0], [85.6, 2584.0], [85.7, 2587.0], [85.8, 2589.0], [85.9, 2589.0], [86.0, 2591.0], [86.1, 2591.0], [86.2, 2593.0], [86.3, 2600.0], [86.4, 2608.0], [86.5, 2613.0], [86.6, 2618.0], [86.7, 2619.0], [86.8, 2621.0], [86.9, 2624.0], [87.0, 2628.0], [87.1, 2649.0], [87.2, 2667.0], [87.3, 2676.0], [87.4, 2689.0], [87.5, 2690.0], [87.6, 2701.0], [87.7, 2708.0], [87.8, 2710.0], [87.9, 2711.0], [88.0, 2712.0], [88.1, 2713.0], [88.2, 2720.0], [88.3, 2725.0], [88.4, 2727.0], [88.5, 2728.0], [88.6, 2733.0], [88.7, 2744.0], [88.8, 2746.0], [88.9, 2760.0], [89.0, 2760.0], [89.1, 2761.0], [89.2, 2761.0], [89.3, 2763.0], [89.4, 2775.0], [89.5, 2778.0], [89.6, 2783.0], [89.7, 2784.0], [89.8, 2814.0], [89.9, 2819.0], [90.0, 2819.0], [90.1, 2819.0], [90.2, 2827.0], [90.3, 2828.0], [90.4, 2854.0], [90.5, 2862.0], [90.6, 2862.0], [90.7, 2864.0], [90.8, 2869.0], [90.9, 2871.0], [91.0, 2875.0], [91.1, 2875.0], [91.2, 2882.0], [91.3, 2883.0], [91.4, 2891.0], [91.5, 2897.0], [91.6, 2911.0], [91.7, 2916.0], [91.8, 2917.0], [91.9, 2924.0], [92.0, 2924.0], [92.1, 2928.0], [92.2, 2946.0], [92.3, 2953.0], [92.4, 2953.0], [92.5, 2955.0], [92.6, 2961.0], [92.7, 2975.0], [92.8, 2976.0], [92.9, 2978.0], [93.0, 2983.0], [93.1, 2984.0], [93.2, 2985.0], [93.3, 2990.0], [93.4, 2993.0], [93.5, 3004.0], [93.6, 3013.0], [93.7, 3046.0], [93.8, 3062.0], [93.9, 3065.0], [94.0, 3067.0], [94.1, 3084.0], [94.2, 3097.0], [94.3, 3109.0], [94.4, 3122.0], [94.5, 3143.0], [94.6, 3144.0], [94.7, 3148.0], [94.8, 3153.0], [94.9, 3154.0], [95.0, 3163.0], [95.1, 3165.0], [95.2, 3175.0], [95.3, 3204.0], [95.4, 3208.0], [95.5, 3209.0], [95.6, 3211.0], [95.7, 3224.0], [95.8, 3242.0], [95.9, 3265.0], [96.0, 3275.0], [96.1, 3277.0], [96.2, 3282.0], [96.3, 3283.0], [96.4, 3286.0], [96.5, 3288.0], [96.6, 3302.0], [96.7, 3318.0], [96.8, 3331.0], [96.9, 3375.0], [97.0, 3381.0], [97.1, 3381.0], [97.2, 3384.0], [97.3, 3404.0], [97.4, 3410.0], [97.5, 3412.0], [97.6, 3487.0], [97.7, 3490.0], [97.8, 3492.0], [97.9, 3492.0], [98.0, 3494.0], [98.1, 3515.0], [98.2, 3532.0], [98.3, 3551.0], [98.4, 3552.0], [98.5, 3553.0], [98.6, 3561.0], [98.7, 3563.0], [98.8, 3591.0], [98.9, 3599.0], [99.0, 3652.0], [99.1, 3663.0], [99.2, 3667.0], [99.3, 3702.0], [99.4, 3712.0], [99.5, 3750.0], [99.6, 3770.0], [99.7, 3826.0], [99.8, 4026.0], [99.9, 4198.0]], "isOverall": false, "label": "POST login", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Response Time Percentiles"}},
        getOptions: function() {
            return {
                series: {
                    points: { show: false }
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentiles'
                },
                xaxis: {
                    tickDecimals: 1,
                    axisLabel: "Percentiles",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Percentile value in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : %x.2 percentile was %y ms"
                },
                selection: { mode: "xy" },
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentiles"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesPercentiles"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesPercentiles"), dataset, prepareOverviewOptions(options));
        }
};

/**
 * @param elementId Id of element where we display message
 */
function setEmptyGraph(elementId) {
    $(function() {
        $(elementId).text("No graph series with filter="+seriesFilter);
    });
}

// Response times percentiles
function refreshResponseTimePercentiles() {
    var infos = responseTimePercentilesInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimePercentiles");
        return;
    }
    if (isGraph($("#flotResponseTimesPercentiles"))){
        infos.createGraph();
    } else {
        var choiceContainer = $("#choicesResponseTimePercentiles");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesPercentiles", "#overviewResponseTimesPercentiles");
        $('#bodyResponseTimePercentiles .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimeDistributionInfos = {
        data: {"result": {"minY": 1.0, "minX": 100.0, "maxY": 52.0, "series": [{"data": [[600.0, 43.0], [700.0, 51.0], [800.0, 41.0], [900.0, 48.0], [1000.0, 45.0], [1100.0, 44.0], [1200.0, 42.0], [1300.0, 40.0], [1400.0, 36.0], [1500.0, 32.0], [100.0, 12.0], [1600.0, 29.0], [1700.0, 28.0], [1800.0, 28.0], [1900.0, 26.0], [2000.0, 35.0], [2100.0, 33.0], [2200.0, 19.0], [2300.0, 19.0], [2400.0, 24.0], [2500.0, 31.0], [2600.0, 13.0], [2700.0, 22.0], [2800.0, 18.0], [2900.0, 19.0], [3000.0, 8.0], [3100.0, 10.0], [200.0, 25.0], [3300.0, 7.0], [3200.0, 13.0], [3400.0, 8.0], [3500.0, 9.0], [3700.0, 4.0], [3600.0, 3.0], [3800.0, 1.0], [4000.0, 1.0], [4100.0, 1.0], [300.0, 30.0], [400.0, 50.0], [500.0, 52.0]], "isOverall": false, "label": "POST login", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 100, "maxX": 4100.0, "title": "Response Time Distribution"}},
        getOptions: function() {
            var granularity = this.data.result.granularity;
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    barWidth: this.data.result.granularity
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " responses for " + label + " were between " + xval + " and " + (xval + granularity) + " ms";
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimeDistribution"), prepareData(data.result.series, $("#choicesResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshResponseTimeDistribution() {
    var infos = responseTimeDistributionInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeDistribution");
        return;
    }
    if (isGraph($("#flotResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var syntheticResponseTimeDistributionInfos = {
        data: {"result": {"minY": 118.0, "minX": 0.0, "ticks": [[0, "Requests having \nresponse time <= 500ms"], [1, "Requests having \nresponse time > 500ms and <= 1,500ms"], [2, "Requests having \nresponse time > 1,500ms"], [3, "Requests in error"]], "maxY": 441.0, "series": [{"data": [[0.0, 118.0]], "color": "#9ACD32", "isOverall": false, "label": "Requests having \nresponse time <= 500ms", "isController": false}, {"data": [[1.0, 441.0]], "color": "yellow", "isOverall": false, "label": "Requests having \nresponse time > 500ms and <= 1,500ms", "isController": false}, {"data": [[2.0, 441.0]], "color": "orange", "isOverall": false, "label": "Requests having \nresponse time > 1,500ms", "isController": false}, {"data": [], "color": "#FF6347", "isOverall": false, "label": "Requests in error", "isController": false}], "supportsControllersDiscrimination": false, "maxX": 2.0, "title": "Synthetic Response Times Distribution"}},
        getOptions: function() {
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendSyntheticResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times ranges",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                    tickLength:0,
                    min:-0.5,
                    max:3.5
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    align: "center",
                    barWidth: 0.25,
                    fill:.75
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " " + label;
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            options.xaxis.ticks = data.result.ticks;
            $.plot($("#flotSyntheticResponseTimeDistribution"), prepareData(data.result.series, $("#choicesSyntheticResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshSyntheticResponseTimeDistribution() {
    var infos = syntheticResponseTimeDistributionInfos;
    prepareSeries(infos.data, true);
    if (isGraph($("#flotSyntheticResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerSyntheticResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var activeThreadsOverTimeInfos = {
        data: {"result": {"minY": 91.14799999999993, "minX": 1.79488596E12, "maxY": 91.14799999999993, "series": [{"data": [[1.79488596E12, 91.14799999999993]], "isOverall": false, "label": "E5 - Estrés: saturación progresiva de login", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.79488596E12, "title": "Active Threads Over Time"}},
        getOptions: function() {
            return {
                series: {
                    stack: true,
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 6,
                    show: true,
                    container: '#legendActiveThreadsOverTime'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                selection: {
                    mode: 'xy'
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : At %x there were %y active threads"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesActiveThreadsOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotActiveThreadsOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewActiveThreadsOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Active Threads Over Time
function refreshActiveThreadsOverTime(fixTimestamps) {
    var infos = activeThreadsOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotActiveThreadsOverTime"))) {
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesActiveThreadsOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotActiveThreadsOverTime", "#overviewActiveThreadsOverTime");
        $('#footerActiveThreadsOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var timeVsThreadsInfos = {
        data: {"result": {"minY": 132.0, "minX": 1.0, "maxY": 2864.0, "series": [{"data": [[2.0, 164.0], [3.0, 211.0], [4.0, 461.0], [7.0, 481.3333333333333], [8.0, 209.0], [9.0, 319.0], [10.0, 488.0], [11.0, 337.66666666666663], [12.0, 292.5], [13.0, 539.6666666666666], [14.0, 258.6666666666667], [15.0, 361.0], [16.0, 325.0], [17.0, 190.5], [18.0, 890.0], [19.0, 208.5], [20.0, 489.0], [21.0, 693.25], [22.0, 445.0], [23.0, 571.75], [24.0, 787.0], [25.0, 570.7142857142858], [26.0, 591.0], [27.0, 330.0], [28.0, 587.8], [29.0, 373.3333333333333], [30.0, 469.6], [31.0, 798.0], [32.0, 548.0], [33.0, 555.0], [34.0, 534.0], [35.0, 555.8333333333333], [36.0, 515.0], [37.0, 689.25], [38.0, 765.75], [39.0, 682.4285714285714], [40.0, 584.5714285714286], [41.0, 606.6666666666666], [42.0, 567.5714285714287], [43.0, 596.2857142857143], [44.0, 756.6], [45.0, 581.8], [46.0, 597.8333333333334], [47.0, 688.5], [48.0, 666.9166666666667], [49.0, 755.4285714285714], [50.0, 817.0], [51.0, 828.1111111111111], [52.0, 774.6666666666666], [53.0, 675.0], [54.0, 504.5], [55.0, 732.3333333333334], [56.0, 827.0], [57.0, 512.0], [58.0, 964.75], [59.0, 910.0], [60.0, 827.25], [61.0, 751.6666666666666], [63.0, 975.4], [62.0, 925.3333333333334], [64.0, 1062.375], [65.0, 1266.25], [66.0, 1043.6666666666667], [67.0, 797.8], [68.0, 1286.5714285714287], [69.0, 1175.1999999999998], [70.0, 1080.25], [71.0, 1013.0], [73.0, 1513.9999999999998], [72.0, 1428.5], [74.0, 1038.0], [75.0, 1068.5], [76.0, 1239.1538461538462], [77.0, 1199.7142857142858], [78.0, 1114.5], [79.0, 1217.4], [80.0, 1556.7777777777778], [81.0, 1420.25], [82.0, 1056.875], [83.0, 1431.1176470588234], [84.0, 1165.8], [85.0, 1026.3333333333335], [86.0, 1049.857142857143], [87.0, 1883.0], [88.0, 1811.1538461538464], [89.0, 1178.1666666666667], [90.0, 1773.3333333333333], [91.0, 1654.6666666666667], [93.0, 1225.5], [94.0, 1309.8], [95.0, 1341.25], [92.0, 1414.0], [96.0, 1599.142857142857], [97.0, 1916.6], [99.0, 1796.8333333333333], [98.0, 774.5], [100.0, 1592.0], [101.0, 1741.0], [103.0, 1499.5], [102.0, 1994.3333333333333], [104.0, 1505.6363636363637], [105.0, 1459.0], [106.0, 1600.6], [107.0, 1641.0], [108.0, 1413.111111111111], [109.0, 1770.125], [110.0, 1981.6], [111.0, 1613.7142857142858], [112.0, 1784.0625], [114.0, 1561.1666666666665], [113.0, 1942.157894736842], [115.0, 1976.0], [116.0, 2042.6000000000004], [117.0, 2062.7142857142862], [118.0, 2239.4285714285716], [119.0, 2690.0], [120.0, 1675.2], [121.0, 2173.7], [122.0, 1971.5], [123.0, 1992.2702702702707], [124.0, 2263.25], [125.0, 1597.625], [126.0, 1953.5555555555557], [127.0, 1941.5], [128.0, 2214.666666666667], [129.0, 1854.0], [130.0, 2296.928571428571], [131.0, 2320.875], [133.0, 2463.761904761905], [134.0, 2574.0833333333335], [135.0, 2363.423076923077], [132.0, 2596.25], [137.0, 2399.5], [138.0, 1998.625], [139.0, 2031.4999999999998], [140.0, 2256.8666666666672], [141.0, 2636.25], [142.0, 2154.0], [143.0, 1953.0], [136.0, 2864.0], [144.0, 2361.0000000000005], [145.0, 2606.272727272727], [146.0, 2232.0], [147.0, 2008.6], [148.0, 2285.0], [149.0, 1715.3333333333333], [1.0, 132.0]], "isOverall": false, "label": "POST login", "isController": false}, {"data": [[91.14799999999993, 1509.9670000000003]], "isOverall": false, "label": "POST login-Aggregated", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 149.0, "title": "Time VS Threads"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: { noColumns: 2,show: true, container: '#legendTimeVsThreads' },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s: At %x.2 active threads, Average response time was %y.2 ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesTimeVsThreads"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotTimesVsThreads"), dataset, options);
            // setup overview
            $.plot($("#overviewTimesVsThreads"), dataset, prepareOverviewOptions(options));
        }
};

// Time vs threads
function refreshTimeVsThreads(){
    var infos = timeVsThreadsInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTimeVsThreads");
        return;
    }
    if(isGraph($("#flotTimesVsThreads"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTimeVsThreads");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTimesVsThreads", "#overviewTimesVsThreads");
        $('#footerTimeVsThreads .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var bytesThroughputOverTimeInfos = {
        data : {"result": {"minY": 4613.666666666667, "minX": 1.79488596E12, "maxY": 13308.0, "series": [{"data": [[1.79488596E12, 13308.0]], "isOverall": false, "label": "Bytes received per second", "isController": false}, {"data": [[1.79488596E12, 4613.666666666667]], "isOverall": false, "label": "Bytes sent per second", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.79488596E12, "title": "Bytes Throughput Over Time"}},
        getOptions : function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity) ,
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Bytes / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendBytesThroughputOverTime'
                },
                selection: {
                    mode: "xy"
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y"
                }
            };
        },
        createGraph : function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesBytesThroughputOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotBytesThroughputOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewBytesThroughputOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Bytes throughput Over Time
function refreshBytesThroughputOverTime(fixTimestamps) {
    var infos = bytesThroughputOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotBytesThroughputOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesBytesThroughputOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotBytesThroughputOverTime", "#overviewBytesThroughputOverTime");
        $('#footerBytesThroughputOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimesOverTimeInfos = {
        data: {"result": {"minY": 1509.9670000000003, "minX": 1.79488596E12, "maxY": 1509.9670000000003, "series": [{"data": [[1.79488596E12, 1509.9670000000003]], "isOverall": false, "label": "POST login", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.79488596E12, "title": "Response Time Over Time"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average response time was %y ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Times Over Time
function refreshResponseTimeOverTime(fixTimestamps) {
    var infos = responseTimesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotResponseTimesOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesOverTime", "#overviewResponseTimesOverTime");
        $('#footerResponseTimesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var latenciesOverTimeInfos = {
        data: {"result": {"minY": 1509.9209999999985, "minX": 1.79488596E12, "maxY": 1509.9209999999985, "series": [{"data": [[1.79488596E12, 1509.9209999999985]], "isOverall": false, "label": "POST login", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.79488596E12, "title": "Latencies Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response latencies in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendLatenciesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average latency was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesLatenciesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotLatenciesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewLatenciesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Latencies Over Time
function refreshLatenciesOverTime(fixTimestamps) {
    var infos = latenciesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyLatenciesOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotLatenciesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesLatenciesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotLatenciesOverTime", "#overviewLatenciesOverTime");
        $('#footerLatenciesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var connectTimeOverTimeInfos = {
        data: {"result": {"minY": 0.8669999999999983, "minX": 1.79488596E12, "maxY": 0.8669999999999983, "series": [{"data": [[1.79488596E12, 0.8669999999999983]], "isOverall": false, "label": "POST login", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.79488596E12, "title": "Connect Time Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getConnectTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average Connect Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendConnectTimeOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average connect time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesConnectTimeOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotConnectTimeOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewConnectTimeOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Connect Time Over Time
function refreshConnectTimeOverTime(fixTimestamps) {
    var infos = connectTimeOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyConnectTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotConnectTimeOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesConnectTimeOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotConnectTimeOverTime", "#overviewConnectTimeOverTime");
        $('#footerConnectTimeOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var responseTimePercentilesOverTimeInfos = {
        data: {"result": {"minY": 132.0, "minX": 1.79488596E12, "maxY": 4198.0, "series": [{"data": [[1.79488596E12, 4198.0]], "isOverall": false, "label": "Max", "isController": false}, {"data": [[1.79488596E12, 132.0]], "isOverall": false, "label": "Min", "isController": false}, {"data": [[1.79488596E12, 2819.0]], "isOverall": false, "label": "90th percentile", "isController": false}, {"data": [[1.79488596E12, 3651.4700000000003]], "isOverall": false, "label": "99th percentile", "isController": false}, {"data": [[1.79488596E12, 1336.5]], "isOverall": false, "label": "Median", "isController": false}, {"data": [[1.79488596E12, 3162.5499999999993]], "isOverall": false, "label": "95th percentile", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.79488596E12, "title": "Response Time Percentiles Over Time (successful requests only)"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentilesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Response time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentilesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimePercentilesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimePercentilesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Time Percentiles Over Time
function refreshResponseTimePercentilesOverTime(fixTimestamps) {
    var infos = responseTimePercentilesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotResponseTimePercentilesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimePercentilesOverTime", "#overviewResponseTimePercentilesOverTime");
        $('#footerResponseTimePercentilesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var responseTimeVsRequestInfos = {
    data: {"result": {"minY": 286.0, "minX": 28.0, "maxY": 2698.5, "series": [{"data": [[41.0, 2116.0], [45.0, 2133.0], [46.0, 1629.0], [49.0, 474.0], [50.0, 1310.5], [51.0, 1890.0], [54.0, 1242.0], [56.0, 1166.0], [58.0, 662.5], [62.0, 1686.5], [63.0, 657.0], [68.0, 2352.0], [88.0, 2698.5], [89.0, 1789.0], [102.0, 1092.0], [28.0, 286.0]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 102.0, "title": "Response Time Vs Request"}},
    getOptions: function() {
        return {
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Response Time in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: {
                noColumns: 2,
                show: true,
                container: '#legendResponseTimeVsRequest'
            },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median response time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesResponseTimeVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotResponseTimeVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewResponseTimeVsRequest"), dataset, prepareOverviewOptions(options));

    }
};

// Response Time vs Request
function refreshResponseTimeVsRequest() {
    var infos = responseTimeVsRequestInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimeVsRequest"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeVsRequest");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimeVsRequest", "#overviewResponseTimeVsRequest");
        $('#footerResponseRimeVsRequest .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var latenciesVsRequestInfos = {
    data: {"result": {"minY": 285.5, "minX": 28.0, "maxY": 2698.5, "series": [{"data": [[41.0, 2116.0], [45.0, 2133.0], [46.0, 1629.0], [49.0, 472.0], [50.0, 1310.5], [51.0, 1890.0], [54.0, 1242.0], [56.0, 1166.0], [58.0, 662.5], [62.0, 1686.5], [63.0, 657.0], [68.0, 2352.0], [88.0, 2698.5], [89.0, 1789.0], [102.0, 1091.5], [28.0, 285.5]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 102.0, "title": "Latencies Vs Request"}},
    getOptions: function() {
        return{
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Latency in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: { noColumns: 2,show: true, container: '#legendLatencyVsRequest' },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median Latency time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesLatencyVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotLatenciesVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewLatenciesVsRequest"), dataset, prepareOverviewOptions(options));
    }
};

// Latencies vs Request
function refreshLatenciesVsRequest() {
        var infos = latenciesVsRequestInfos;
        prepareSeries(infos.data);
        if(isGraph($("#flotLatenciesVsRequest"))){
            infos.createGraph();
        }else{
            var choiceContainer = $("#choicesLatencyVsRequest");
            createLegend(choiceContainer, infos);
            infos.createGraph();
            setGraphZoomable("#flotLatenciesVsRequest", "#overviewLatenciesVsRequest");
            $('#footerLatenciesVsRequest .legendColorBox > div').each(function(i){
                $(this).clone().prependTo(choiceContainer.find("li").eq(i));
            });
        }
};

var hitsPerSecondInfos = {
        data: {"result": {"minY": 16.666666666666668, "minX": 1.79488596E12, "maxY": 16.666666666666668, "series": [{"data": [[1.79488596E12, 16.666666666666668]], "isOverall": false, "label": "hitsPerSecond", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.79488596E12, "title": "Hits Per Second"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of hits / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendHitsPerSecond"
                },
                selection: {
                    mode : 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y.2 hits/sec"
                }
            };
        },
        createGraph: function createGraph() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesHitsPerSecond"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotHitsPerSecond"), dataset, options);
            // setup overview
            $.plot($("#overviewHitsPerSecond"), dataset, prepareOverviewOptions(options));
        }
};

// Hits per second
function refreshHitsPerSecond(fixTimestamps) {
    var infos = hitsPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if (isGraph($("#flotHitsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesHitsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotHitsPerSecond", "#overviewHitsPerSecond");
        $('#footerHitsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var codesPerSecondInfos = {
        data: {"result": {"minY": 16.666666666666668, "minX": 1.79488596E12, "maxY": 16.666666666666668, "series": [{"data": [[1.79488596E12, 16.666666666666668]], "isOverall": false, "label": "200", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.79488596E12, "title": "Codes Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendCodesPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "Number of Response Codes %s at %x was %y.2 responses / sec"
                }
            };
        },
    createGraph: function() {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesCodesPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotCodesPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewCodesPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Codes per second
function refreshCodesPerSecond(fixTimestamps) {
    var infos = codesPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotCodesPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesCodesPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotCodesPerSecond", "#overviewCodesPerSecond");
        $('#footerCodesPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var transactionsPerSecondInfos = {
        data: {"result": {"minY": 16.666666666666668, "minX": 1.79488596E12, "maxY": 16.666666666666668, "series": [{"data": [[1.79488596E12, 16.666666666666668]], "isOverall": false, "label": "POST login-success", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.79488596E12, "title": "Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTransactionsPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                }
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTransactionsPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTransactionsPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewTransactionsPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Transactions per second
function refreshTransactionsPerSecond(fixTimestamps) {
    var infos = transactionsPerSecondInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTransactionsPerSecond");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotTransactionsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTransactionsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTransactionsPerSecond", "#overviewTransactionsPerSecond");
        $('#footerTransactionsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var totalTPSInfos = {
        data: {"result": {"minY": 16.666666666666668, "minX": 1.79488596E12, "maxY": 16.666666666666668, "series": [{"data": [[1.79488596E12, 16.666666666666668]], "isOverall": false, "label": "Transaction-success", "isController": false}, {"data": [], "isOverall": false, "label": "Transaction-failure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.79488596E12, "title": "Total Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTotalTPS"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                },
                colors: ["#9ACD32", "#FF6347"]
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTotalTPS"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTotalTPS"), dataset, options);
        // setup overview
        $.plot($("#overviewTotalTPS"), dataset, prepareOverviewOptions(options));
    }
};

// Total Transactions per second
function refreshTotalTPS(fixTimestamps) {
    var infos = totalTPSInfos;
    // We want to ignore seriesFilter
    prepareSeries(infos.data, false, true);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotTotalTPS"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTotalTPS");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTotalTPS", "#overviewTotalTPS");
        $('#footerTotalTPS .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

// Collapse the graph matching the specified DOM element depending the collapsed
// status
function collapse(elem, collapsed){
    if(collapsed){
        $(elem).parent().find(".fa-chevron-up").removeClass("fa-chevron-up").addClass("fa-chevron-down");
    } else {
        $(elem).parent().find(".fa-chevron-down").removeClass("fa-chevron-down").addClass("fa-chevron-up");
        if (elem.id == "bodyBytesThroughputOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshBytesThroughputOverTime(true);
            }
            document.location.href="#bytesThroughputOverTime";
        } else if (elem.id == "bodyLatenciesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesOverTime(true);
            }
            document.location.href="#latenciesOverTime";
        } else if (elem.id == "bodyCustomGraph") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCustomGraph(true);
            }
            document.location.href="#responseCustomGraph";
        } else if (elem.id == "bodyConnectTimeOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshConnectTimeOverTime(true);
            }
            document.location.href="#connectTimeOverTime";
        } else if (elem.id == "bodyResponseTimePercentilesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimePercentilesOverTime(true);
            }
            document.location.href="#responseTimePercentilesOverTime";
        } else if (elem.id == "bodyResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeDistribution();
            }
            document.location.href="#responseTimeDistribution" ;
        } else if (elem.id == "bodySyntheticResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshSyntheticResponseTimeDistribution();
            }
            document.location.href="#syntheticResponseTimeDistribution" ;
        } else if (elem.id == "bodyActiveThreadsOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshActiveThreadsOverTime(true);
            }
            document.location.href="#activeThreadsOverTime";
        } else if (elem.id == "bodyTimeVsThreads") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTimeVsThreads();
            }
            document.location.href="#timeVsThreads" ;
        } else if (elem.id == "bodyCodesPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCodesPerSecond(true);
            }
            document.location.href="#codesPerSecond";
        } else if (elem.id == "bodyTransactionsPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTransactionsPerSecond(true);
            }
            document.location.href="#transactionsPerSecond";
        } else if (elem.id == "bodyTotalTPS") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTotalTPS(true);
            }
            document.location.href="#totalTPS";
        } else if (elem.id == "bodyResponseTimeVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeVsRequest();
            }
            document.location.href="#responseTimeVsRequest";
        } else if (elem.id == "bodyLatenciesVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesVsRequest();
            }
            document.location.href="#latencyVsRequest";
        }
    }
}

/*
 * Activates or deactivates all series of the specified graph (represented by id parameter)
 * depending on checked argument.
 */
function toggleAll(id, checked){
    var placeholder = document.getElementById(id);

    var cases = $(placeholder).find(':checkbox');
    cases.prop('checked', checked);
    $(cases).parent().children().children().toggleClass("legend-disabled", !checked);

    var choiceContainer;
    if ( id == "choicesBytesThroughputOverTime"){
        choiceContainer = $("#choicesBytesThroughputOverTime");
        refreshBytesThroughputOverTime(false);
    } else if(id == "choicesResponseTimesOverTime"){
        choiceContainer = $("#choicesResponseTimesOverTime");
        refreshResponseTimeOverTime(false);
    }else if(id == "choicesResponseCustomGraph"){
        choiceContainer = $("#choicesResponseCustomGraph");
        refreshCustomGraph(false);
    } else if ( id == "choicesLatenciesOverTime"){
        choiceContainer = $("#choicesLatenciesOverTime");
        refreshLatenciesOverTime(false);
    } else if ( id == "choicesConnectTimeOverTime"){
        choiceContainer = $("#choicesConnectTimeOverTime");
        refreshConnectTimeOverTime(false);
    } else if ( id == "choicesResponseTimePercentilesOverTime"){
        choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        refreshResponseTimePercentilesOverTime(false);
    } else if ( id == "choicesResponseTimePercentiles"){
        choiceContainer = $("#choicesResponseTimePercentiles");
        refreshResponseTimePercentiles();
    } else if(id == "choicesActiveThreadsOverTime"){
        choiceContainer = $("#choicesActiveThreadsOverTime");
        refreshActiveThreadsOverTime(false);
    } else if ( id == "choicesTimeVsThreads"){
        choiceContainer = $("#choicesTimeVsThreads");
        refreshTimeVsThreads();
    } else if ( id == "choicesSyntheticResponseTimeDistribution"){
        choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        refreshSyntheticResponseTimeDistribution();
    } else if ( id == "choicesResponseTimeDistribution"){
        choiceContainer = $("#choicesResponseTimeDistribution");
        refreshResponseTimeDistribution();
    } else if ( id == "choicesHitsPerSecond"){
        choiceContainer = $("#choicesHitsPerSecond");
        refreshHitsPerSecond(false);
    } else if(id == "choicesCodesPerSecond"){
        choiceContainer = $("#choicesCodesPerSecond");
        refreshCodesPerSecond(false);
    } else if ( id == "choicesTransactionsPerSecond"){
        choiceContainer = $("#choicesTransactionsPerSecond");
        refreshTransactionsPerSecond(false);
    } else if ( id == "choicesTotalTPS"){
        choiceContainer = $("#choicesTotalTPS");
        refreshTotalTPS(false);
    } else if ( id == "choicesResponseTimeVsRequest"){
        choiceContainer = $("#choicesResponseTimeVsRequest");
        refreshResponseTimeVsRequest();
    } else if ( id == "choicesLatencyVsRequest"){
        choiceContainer = $("#choicesLatencyVsRequest");
        refreshLatenciesVsRequest();
    }
    var color = checked ? "black" : "#818181";
    if(choiceContainer != null) {
        choiceContainer.find("label").each(function(){
            this.style.color = color;
        });
    }
}

